﻿using System.Collections.Generic;

namespace VertMarkets
{
    public class Magazines
    {
        public List<MagazineCategory> Data { get; set; }
        public bool Success { get; set; }
        public string Token { get; set; }

        public Magazines()
        {
            Data = new List<MagazineCategory>();
            Success = false;
            Token = string.Empty;
        }
    }

}
