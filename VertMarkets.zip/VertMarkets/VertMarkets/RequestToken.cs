﻿namespace VertMarkets
{
    public class RequestToken
    {
        public bool Success { get; set; }
        public string Token { get; set; }
    }

}