﻿using System;
using System.Collections.Generic;

namespace VertMarkets
{
    public class Subscriber
    {
        public string Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public List<int> MagazineIds { get; set; }

        public Subscriber()
        {
            MagazineIds = new List<int>();
            Id = string.Empty;
            FirstName = string.Empty;
            LastName = string.Empty;
        }
    }
}
