﻿To run the application do the following steps:

1) Install .Net Core latest version (preferably v5.0) from https://dotnet.microsoft.com/download/dotnet/5.0
2) Once the sdk's, runtime installed navigate to the project path [ where .sln folder available] in command prompt.
3) On navigation to the path, run 'dotnet restore' to restore the project dependencies
4) Once restored, do 'dotnet build' to build the project.
5) Once the build is successful, run 'dotnet run pathToProject\VertMarkets\VertMarkets.csproj'
6) Once the project is run, you will see the output [subscriber id's separated by comma] in the window. 
