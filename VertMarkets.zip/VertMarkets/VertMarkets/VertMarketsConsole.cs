﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Threading.Tasks;
using Newtonsoft.Json;
using RestSharp;
using RestSharp.Authenticators;
using System.Linq;
using System.Text;

namespace VertMarkets
{
    internal class VertMarketsConsole
    {
        private const string Endpoint = "http://magazinestore.azurewebsites.net";

        private const string Categories = "/api/categories/";
        private const string MagazineCategories = "/api/magazines/";
        private const string Subscribers = "/api/subscribers/";
        private const string Token = "/api/token";
        private const string Answer = "/api/answer/";

        private readonly RestClient client;

        public VertMarketsConsole()
        {
            client = new RestClient(new Uri(Endpoint, UriKind.Absolute))
            {
                Authenticator = new NtlmAuthenticator()
            };
        }

        internal async Task<string> PostAnswer()
        {
            var result = string.Empty;
            var token = await GetRequestToken();
            if (token != null && !string.IsNullOrWhiteSpace(token.Token))
            {
                var categories = await GetCategories(token?.Token);
                var subscribers = await GetSubscribers(token?.Token);

                var magazineCategory = new ConcurrentDictionary<string, List<int>>();
                foreach(var category in categories?.Data)
                {
                    var magazines = await GetMagazineCategory(token?.Token, category);                    
                    if(magazineCategory.ContainsKey(category))
                    {
                        magazineCategory[category].AddRange(magazines?.Data.Select(d => d.Id));
                    }
                    else
                    {
                        var magazineIds = new List<int>();
                        magazineIds.AddRange(magazines?.Data.Select(d => d.Id));
                        magazineCategory.TryAdd(category, magazineIds);
                    }
                }                

                var magSubs = new ConcurrentDictionary<string, int>();
                foreach (var subscriber in subscribers?.Data) 
                {
                    foreach (var magCat in magazineCategory)
                    {
                        if (subscriber.MagazineIds.Intersect(magCat.Value).Any())
                        {
                            if (magSubs.ContainsKey(subscriber.Id))
                            {
                                magSubs[subscriber.Id] += 1;
                            }
                            else
                            {
                                magSubs.TryAdd(subscriber.Id, 1);
                            }
                        }
                    }
                }

                var output = magSubs.Where(ms => ms.Value == categories?.Data.Count).Select(sub => sub.Key).ToList();
                if (output.Any())
                {
                    result = output.Aggregate( new StringBuilder(), (current, next) => current.Append(current.Length == 0 ? "" : ", ").Append(next)).ToString();
                    await PostToServer(token.Token, output);
                }
            }

            return result;
        }

        private async Task<List<string>> PostToServer(string token, List<string> subscriberIds)
        {
            var response = new List<string>();
            try
            {
                if (string.IsNullOrWhiteSpace(token))
                {
                    Console.WriteLine("Request token not set...");
                    return response;
                }

                var request = new RestRequest($"{Answer}{token}");
                request.AddJsonBody(subscriberIds);

                response = await client.PostAsync<List<string>>(request);
                return response;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error while getting token...\n" + ex.Message);
                return new List<string>();
            }
        }

        private async Task<RequestToken> GetRequestToken()
        {
            try
            {
                var request = new RestRequest($"{Token}");
                var response = await client.GetAsync<RequestToken>(request);
                return response;
            }
            catch(Exception ex)
            {
                Console.WriteLine("Error while getting token...\n" + ex.Message);
                return new RequestToken() { Success = false, Token = string.Empty };
            }
        }

        private async Task<Categories> GetCategories(string token)
        {
            var response = new Categories();

            if (string.IsNullOrWhiteSpace(token))
            {
                Console.WriteLine("Request token not set...");
                return response;
            }

            try
            {
                var request = new RestRequest($"{Categories}{token}");
                response = await client.GetAsync<Categories>(request);
                return response;
            }
            catch(Exception ex)
            {
                Console.WriteLine("Error while getting categories...\n" + ex.Message);
                return response;
            }
        }

        private async Task<MagazineSubscriber> GetSubscribers(string token)
        {
            var response = new MagazineSubscriber();

            if (string.IsNullOrWhiteSpace(token))
            {
                Console.WriteLine("Request token not set...");
                return response;
            }

            try
            {
                var request = new RestRequest($"{Subscribers}{token}");
                response = await client.GetAsync<MagazineSubscriber>(request);
                return response;
            }
            catch(Exception ex)
            {
                Console.WriteLine("Error while getting subscribers...\n" + ex.Message);
                return response;
            }
        }

        private async Task<Magazines> GetMagazineCategory(string token,string category)
        {
            var response = new Magazines();

            if (string.IsNullOrWhiteSpace(token))
            {
                Console.WriteLine("Request token not set...");
                return response;
            }

            try
            {
                var request = new RestRequest($"{MagazineCategories}{token}/{category}");
                response = await client.GetAsync<Magazines>(request);
                return response;
            }
            catch
            {
                Console.WriteLine("Error while getting magazine categories...");
                return response;
            }
        }
    }

}
