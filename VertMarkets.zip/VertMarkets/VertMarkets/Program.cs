﻿using System;
using System.Threading.Tasks;

namespace VertMarkets
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                var subscribers = new VertMarketsConsole();
                string result = subscribers.PostAnswer().Result;
                Console.WriteLine(result);
                Console.ReadLine();
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
