﻿using System.Collections.Generic;

namespace VertMarkets
{
    public class MagazineSubscriber
    {
        public List<Subscriber> Data { get; set; }
        public bool Success { get; set; }
        public string Token { get; set; }

        public MagazineSubscriber()
        {
            Data = new List<Subscriber>();
            Success = false;
            Token = string.Empty;

        }
    }

}
