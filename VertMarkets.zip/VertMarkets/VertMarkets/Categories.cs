﻿using System.Collections.Generic;

public class Categories
{
    public List<string> Data { get; set; }
    public bool Success { get; set; }
    public string Token { get; set; }

    public Categories()
    {
        Data = new List<string>();
        Success = false;
        Token = string.Empty;
    }

}
